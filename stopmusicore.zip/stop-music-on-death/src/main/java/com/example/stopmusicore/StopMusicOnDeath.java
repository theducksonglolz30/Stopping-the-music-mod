package com.example.stopmusicore;

import net.minecraft.client.Minecraft;
import net.minecraft.client.sounds.MusicManager;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;

import java.lang.reflect.Field;

@Mod("stopmusicore")
public class StopMusicOnDeath {

    public StopMusicOnDeath() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || event.getEntity() != mc.player) return;

        // Stop only the MUSIC channel - this kills ambient background tracks
        // but leaves MASTER/AMBIENT/RECORD channels alone so Epic Death Screen
        // heartbeat and your custom death sound are unaffected.
        mc.getSoundManager().stop(null, SoundSource.MUSIC);

        // Also reset the MusicManager so it doesn't immediately restart a track
        try {
            MusicManager musicManager = mc.getMusicManager();
            // Clear the currently playing music handle via reflection
            Field currentMusicField = ObfuscationReflectionHelper.findField(
                MusicManager.class, "f_120063_"); // currentMusic field (yarn: currentMusic)
            currentMusicField.setAccessible(true);
            currentMusicField.set(musicManager, null);

            // Reset the delay so music doesn't restart right away
            Field nextSongDelayField = ObfuscationReflectionHelper.findField(
                MusicManager.class, "f_120064_"); // nextSongDelay field
            nextSongDelayField.setAccessible(true);
            nextSongDelayField.set(musicManager, 6000); // ~5 minutes delay
        } catch (Exception e) {
            // Reflection failed - the stop(MUSIC) above still works, this just
            // prevents the music from restarting immediately
        }
    }
}
